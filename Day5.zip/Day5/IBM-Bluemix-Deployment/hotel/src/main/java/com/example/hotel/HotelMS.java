package com.example.hotel;

import java.util.ArrayList;
import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("hotel")
@ApplicationScoped
public class HotelMS {
	
	List<String> hotels = new ArrayList<String>();
	
	@GET
	@Produces(value = MediaType.APPLICATION_JSON)
	public List<String> listHotels() {
		System.out.println("INFO=====> HotelMS.listHotels()!!");
		hotels.add("Hyatt");
		hotels.add("Taj Palace");
		hotels.add("Marriot");
		hotels.add("Holiday In");
		return hotels;
	}


}
