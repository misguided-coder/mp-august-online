package com.example.hotel;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("api")
public class MSApp extends Application {

	public MSApp() {
		System.out.println("INFO=====> Inside MSApp constructor!!");
	}

	@Override
	public Set<Object> getSingletons() {
		System.out.println("INFO=====> Inside MSApp.getSingletons()");
		Set<Object> apiEndpoints = new HashSet<>();
		apiEndpoints.add(new HotelMS());
		return apiEndpoints;
	}

}
