public class HolidayPlanner {
	
	public static void main(String[] s){
		System.out.println("Lets holiday and travel in docker container!!");
	}

}